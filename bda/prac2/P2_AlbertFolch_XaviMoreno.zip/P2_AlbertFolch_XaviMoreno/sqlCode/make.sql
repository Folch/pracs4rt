\i delete/delete_fets.sql
\i create/create_fets.sql
\i inserts/inserts.sql
