\i inserts/data/data.sql

\copy Botiga from inserts/data/botiga.csv delimiter ',' csv header
\copy Campanya from inserts/data/campanya.csv delimiter ',' csv header
\copy Color from inserts/data/color.csv delimiter ',' csv header
\copy Edat from inserts/data/edat.csv delimiter ',' csv header
\copy Familia from inserts/data/familia.csv delimiter ',' csv header
\copy Marca from inserts/data/marca.csv delimiter ',' csv header
\copy Pagament from inserts/data/pagament.csv delimiter ',' csv header
\copy Producte from inserts/data/producte.csv delimiter ',' csv header
\copy Talla from inserts/data/talla.csv delimiter ',' csv header
\copy Usuari from inserts/data/usuari.csv delimiter ',' csv header
\copy Fets from inserts/data/fets.csv delimiter ',' csv header

